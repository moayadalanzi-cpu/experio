"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabaseClient";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const router = useRouter();
  const sp = useSearchParams();
  const next = sp.get("next") || "/feed";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const supabase = supabaseBrowser();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      router.push(next);
      router.refresh();
    } catch (err: any) {
      setError(err?.message || "حدث خطأ");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="mx-auto max-w-md p-6">
      <h1 className="text-2xl font-semibold">تسجيل الدخول</h1>
      <p className="mt-2 text-sm text-zinc-600">ادخل البريد وكلمة المرور.</p>

      <form onSubmit={onSubmit} className="mt-6 grid gap-3">
        <input
          className="rounded-xl border px-4 py-3"
          placeholder="البريد الإلكتروني"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
        />
        <input
          className="rounded-xl border px-4 py-3"
          placeholder="كلمة المرور"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
        />

        <button
          type="submit"
          disabled={loading}
          className="rounded-xl bg-zinc-900 px-4 py-3 text-white disabled:opacity-60"
        >
          {loading ? "جاري الدخول..." : "دخول"}
        </button>

        {error && <p className="text-sm text-red-600">{error}</p>}
      </form>

      <div className="mt-4 text-sm">
        ما عندك حساب؟{" "}
        <Link className="underline" href="/auth/signup">
          إنشاء حساب
        </Link>
      </div>
    </main>
  );
}
