export default function LoginPage() {
  return (
    <main style={{padding:24}}>
      <h1>تسجيل الدخول</h1>
      <p>هذه صفحة مؤقتة - سيتم ربط Supabase لاحقاً.</p>
    </main>
  );
}
