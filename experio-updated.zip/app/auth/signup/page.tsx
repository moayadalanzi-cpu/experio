export default function SignupPage() {
  return (
    <main style={{padding:24}}>
      <h1>إنشاء حساب</h1>
      <p>هذه صفحة مؤقتة - سيتم ربط Supabase لاحقاً.</p>
    </main>
  );
}
