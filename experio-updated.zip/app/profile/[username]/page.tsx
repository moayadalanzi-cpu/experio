export default function ProfilePage() {
  return (
    <main style={{padding:24}}>
      <h1>الملف الشخصي</h1>
    </main>
  );
}
