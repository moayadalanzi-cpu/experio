export default function CreatePage() {
  return (
    <main style={{padding:24}}>
      <h1>إنشاء تجربة</h1>
      <p>نموذج إضافة تجربة سيضاف هنا.</p>
    </main>
  );
}
