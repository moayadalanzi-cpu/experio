export default function FeedPage() {
  return (
    <main style={{padding:24}}>
      <h1>Feed</h1>
      <p>هنا ستظهر التجارب.</p>
    </main>
  );
}
